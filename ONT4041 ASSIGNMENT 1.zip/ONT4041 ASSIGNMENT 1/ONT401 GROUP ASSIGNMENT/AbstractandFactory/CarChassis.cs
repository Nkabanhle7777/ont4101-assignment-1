﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class CarChassis : AutoMobilePart //ConcreteProducts
    {
        public override async Task SimulateConstractionDelay()
        {
            //2 seconds
            await Task.Delay(2000);
        }

        //public override async Task SimulateConstructionDelay()
        //{
        //    //2 seconds
        //    await Task.Delay(2000);
        //}

        //public virtual void MakeChassis()
        //{
      
        //    Console.WriteLine("Creating CarChassis {0} " , TheChassis.GetType().Name);
        //    Thread.Sleep(200);
        //}
    }
}
