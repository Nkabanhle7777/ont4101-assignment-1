﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public  static class AssemblyStatus
    {
        //Car Assembly Line (CARLINE) Statuses
        public const string CARLINE_Occupied = "Occupied";
        public const string CARLINE_Available = "Available";

        //MiniBus Assembly Line (MINILINE) Statuses
        public const string MINILINE_Occupied = "Occupied";
        public const string MINILINE_Available = "Available";
    }
}
