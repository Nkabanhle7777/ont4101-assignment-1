﻿using ONT401_GROUP_ASSIGNMENT.SingletonandThreading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public  class MiniBusAssemblyFactory : MiniBusAssemblyFactoryBase
    {
        public MiniBusAssemblyFactory()
        {
            //Initialize MV500 Assembly Queue
            MV500MiniBusAssemblyQueue.InitializeMiniBusAssemblyQueue();
        }
       
    }
}
