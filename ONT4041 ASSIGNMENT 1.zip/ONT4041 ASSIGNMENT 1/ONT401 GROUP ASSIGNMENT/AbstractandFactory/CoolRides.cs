﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    abstract class CoolRides // The base Store
    {
        public CorporateHQ TheFactory { get; set; } //Abstractfactory "has a relationship"

        public CoolRides(CorporateHQ TheFactory)
        {
            TheFactory = TheFactory;
        }

        public AutoMobile orderAutoMobile(string AutoMobileType)
        {
            AutoMobile TheAutoMobile = null;
            if (TheFactory != null)
            {
                TheAutoMobile = makeAutoMobile(AutoMobileType);

                    if (TheAutoMobile != null)
                {
                    TheAutoMobile.MakeShell();
                    TheAutoMobile.AddChassis();
                    TheAutoMobile.Assembly();
                }
            }
            if (TheAutoMobile == null)
                Console.WriteLine("This Shop doesnt make this Automobile" + AutoMobileType);

            Console.WriteLine("Not Available");
            return TheAutoMobile;
        }
        public abstract AutoMobile makeAutoMobile(string AutoMobileType);
    }
}
