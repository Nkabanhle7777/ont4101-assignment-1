﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public abstract class CarAssemblyFactoryBase : IAssemblyFactory
    {
        public virtual IAutoMobile Assemble(IAutoMobile vehicle)
        {
            LUX1000CAR _Lux1000Car = new LUX1000CAR();
            _Lux1000Car.Status = $"Performing Final Assembly of {vehicle.Color} {vehicle.Name}";
            _Lux1000Car.IsCompletelyAssembled = true;
            return _Lux1000Car;
        }
        public static async Task SimulateAssembly()
        {
            //2 seconds
            await Task.Delay(2000);
        }
    }
}
