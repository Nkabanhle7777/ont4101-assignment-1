﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public interface IAutoMobile
    {
        Guid Id { get; }

        string Name { get; set; }

        string Color { get; set; }

        string Status { get; set; }

        string Type { get; set; }

        bool IsCompletelyAssembled { get; set; }
    }
}
