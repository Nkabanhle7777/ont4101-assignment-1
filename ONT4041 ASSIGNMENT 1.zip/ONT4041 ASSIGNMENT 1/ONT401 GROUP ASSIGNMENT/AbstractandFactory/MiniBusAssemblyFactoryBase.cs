﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public class MiniBusAssemblyFactoryBase
    {
        MV500MiniBus _Mv500MiniBus;
        public IAutoMobile Assemble(IAutoMobile autoMobile)
        {
            _Mv500MiniBus = new MV500MiniBus();
            _Mv500MiniBus.Status = $"Final Assembly of {autoMobile.Color} {autoMobile.Name}";
            _Mv500MiniBus.IsCompletelyAssembled = true;
            return _Mv500MiniBus;
        }

        public async Task SimulateAssemblyDaley()
        {
            //2 seconds
            await Task.Delay(2000);
        }
    }
}


