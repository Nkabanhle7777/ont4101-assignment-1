﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    class MiniBusAssemblyLine 
    {
        //Set to available by default
        public static string Status { get; set; } = AssemblyStatus.MINILINE_Available;
        //public MiniBusAssemblyLine() : base(new MiniBusPartsFactory())
        //{

        //}
        //public override AutoMobile makeAutoMobile(string AutoMobileType)
        //{
        //    AutoMobile TheAutoMobile = null;


        //    if (TheFactory != null)
        //    {
        //        switch (AutoMobileType)
        //        {
        //            case "White MV500": TheAutoMobile = new WhiteMV500 (TheFactory); break;
        //            case "Black MV500": TheAutoMobile = new MV500MiniBus(TheFactory); break;
        //        }
        //    }
        //    return TheAutoMobile;
        //}
    }
}
