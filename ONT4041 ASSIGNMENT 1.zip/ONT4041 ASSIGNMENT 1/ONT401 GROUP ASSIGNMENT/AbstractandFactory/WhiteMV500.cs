﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    class WhiteMV500 :AutoMobile
    {
        public WhiteMV500(CorporateHQ TheFactory) : base(TheFactory)
        {
            this.TheShell = TheFactory.GetShell();

            this.TheChassis.Add(TheFactory.GetChassis());
            this.TheChassis.Add(TheFactory.GetChassis());
            this.TheChassis.Add(TheFactory.GetChassis());
        }
    }
}

