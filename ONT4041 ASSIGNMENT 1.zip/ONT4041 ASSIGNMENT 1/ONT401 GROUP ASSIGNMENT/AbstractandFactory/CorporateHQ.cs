﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    abstract class CorporateHQ // AbstractFactory- all the parts needed for the Automobiles
    {
        public abstract IChassis GetChassis();
        
        public abstract IShell GetShell();
        public abstract IWheel GetWheel();
        public abstract ITrim GetTrim();


    }
}
