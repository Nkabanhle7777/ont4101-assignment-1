﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    class MiniBusShell : AutoMobilePart
    {
        public override async Task SimulateConstractionDelay()
        {
            //3 seconds
            await Task.Delay(3000);
        }
    }
}
