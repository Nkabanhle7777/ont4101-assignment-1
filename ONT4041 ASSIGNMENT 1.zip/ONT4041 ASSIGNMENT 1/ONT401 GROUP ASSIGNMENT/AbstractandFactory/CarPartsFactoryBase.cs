﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public abstract class CarPartsFactoryBase : IPartsFactory
    {
        CarChassis _carChassis;
        CarShell _carShell;
        CarTrim _carTrim;
        CarWheel _carWheel;

      

        public AutoMobilePart CreateChassis(IAutoMobile autoMobile)
        {
            _carChassis = new CarChassis();
            _carChassis.Status = $"Creating {autoMobile.Color} {autoMobile.Name} Chassis";
            return _carChassis;
        }

        public AutoMobilePart CreateShell(IAutoMobile autoMobile)
        {
            _carShell = new CarShell();
            _carShell.Status = $"Creating {autoMobile.Color} {autoMobile.Name} shell";
            return _carShell;
        }

        public AutoMobilePart CreateTrim(IAutoMobile autoMobile)
        {
            _carTrim = new CarTrim();
            _carTrim.Status = $"Creating {autoMobile.Color} {autoMobile.Name} trim";
            return _carTrim;
        }

        public AutoMobilePart CreateWheels(IAutoMobile autoMobile)
        {
            _carWheel = new CarWheel();
            foreach (var wheel in _carWheel.GetWheels())
            {
                _carWheel.WheelCreationListStatus.Add($"Creating {autoMobile.Color} {autoMobile.Name} {wheel}");
            }
            return _carWheel;
        }

        
    }
}
