﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    class MiniBusChassis : AutoMobilePart
    {
        public override async Task SimulateConstractionDelay()
        {
            //2 seconds
            await Task.Delay(2000);
        }
    }
}
