﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class MiniBusFactoryBase : IPartsFactory
    {
        MiniBusChassis _miniBusChassis;
        MiniBusShell _miniBusShell;
        MiniBusTrim _miniBusTrim;
        MiniBusWheel _miniBusWheel;


        public AutoMobilePart CreateChassis(IAutoMobile autoMobile)
        {
            _miniBusChassis = new MiniBusChassis();
            _miniBusChassis.Status = $"Creating {autoMobile.Color} {autoMobile.Name} Chassis";
            return _miniBusChassis;
        }

        public AutoMobilePart CreateShell(IAutoMobile autoMobile)
        {
            _miniBusShell = new MiniBusShell();
            _miniBusShell.Status = $"Creating {autoMobile.Color} {autoMobile.Name} Shell";
            return _miniBusShell;
        }

        public AutoMobilePart CreateTrim(IAutoMobile autoMobile)
        {
            _miniBusTrim = new MiniBusTrim();
            _miniBusTrim.Status = $"Creating {autoMobile.Color} {autoMobile.Name} minibus trim";
            return _miniBusTrim;
        }

        public AutoMobilePart CreateWheels(IAutoMobile autoMobile)
        {
            _miniBusWheel = new MiniBusWheel();
            foreach (var wheel in _miniBusWheel.GetWheels())
            {
                _miniBusWheel.WheelCreationListStatus.Add($"Creating {autoMobile.Color} {autoMobile.Name} {wheel}");
            }
            return _miniBusWheel;
        }

    }
}
    
