﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class MV500MiniBus : IAutoMobile
    {
        //public MV500MiniBus(CorporateHQ TheFactory) : base(TheFactory)
        //{
        //    this.TheShell = TheFactory.GetShell();

        //    this.TheChassis.Add(TheFactory.GetChassis());
        //    this.TheChassis.Add(TheFactory.GetChassis());
        //    this.TheChassis.Add(TheFactory.GetChassis());
        //}

        public Guid Id => Guid.NewGuid();

        public string Name { get; set; } = "MV500";
        public string Color { get; set; }
        public string Type { get; set; } = "MiniBus";

        public string Status { get; set; }
        public bool IsCompletelyAssembled { get; set; } = false;
        public MV500MiniBus()
        {

        }
        public MV500MiniBus(string color)
        {
            Color = color;
        }

    }
}
