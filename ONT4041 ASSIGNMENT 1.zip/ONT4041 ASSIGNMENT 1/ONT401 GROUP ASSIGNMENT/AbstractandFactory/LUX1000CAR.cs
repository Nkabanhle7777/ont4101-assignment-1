﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class LUX1000CAR : IAutoMobile
    {
       public Guid Id => Guid.NewGuid();

        public string Name { get; set; } = "LUX1000";

       
        public bool IsCompletelyAssembled { get; set; } = false;

        public string Color { get; set; }

        public string Status { get; set; }

        public string Type { get; set; } = "Car";
        

        public LUX1000CAR()
        {

        }
        public LUX1000CAR(string color)
        {
            Color = color;
        }
    }
}
