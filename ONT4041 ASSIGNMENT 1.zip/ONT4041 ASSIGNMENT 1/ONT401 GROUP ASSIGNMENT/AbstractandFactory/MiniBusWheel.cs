﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    class MiniBusWheel : AutoMobilePart
    {
        public string FrontLeftWheel { get; set; } = "Front Left Wheel";
        public string FrontRightWheel { get; set; } = "Front Right Wheel";
        public string BackLeftWheel { get; set; } = "Back Left Wheel";
        public string BackRightWheel { get; set; } = "Back Right Wheel";

        public List<string> WheelCreationListStatus { get; set; } = new List<string>();

        List<string> _wheels = new List<string>();

          public List<string> GetWheels()
        {
            _wheels.Add(FrontLeftWheel);
            _wheels.Add(FrontRightWheel);
            _wheels.Add(BackLeftWheel);
            _wheels.Add(BackRightWheel);
            return _wheels;
        }
        public override async Task SimulateConstractionDelay()
        {
            //Half a second
            await Task.Delay(500);
        }
    }
}
