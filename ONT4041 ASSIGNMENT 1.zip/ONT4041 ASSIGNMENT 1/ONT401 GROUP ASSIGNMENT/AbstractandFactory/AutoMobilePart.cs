﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public abstract class AutoMobilePart
    {
        public Guid Id { get; private set; } = Guid.NewGuid();

        public string Status { get; set; }

        public abstract Task SimulateConstractionDelay();

       
    }
}
