﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.AbstractandFactory
{
    public interface IPartsFactory
    {
        AutoMobilePart CreateChassis(IAutoMobile autoMobile);
        AutoMobilePart CreateShell(IAutoMobile autoMobile);
        AutoMobilePart CreateTrim(IAutoMobile autoMobile);
        AutoMobilePart CreateWheels(IAutoMobile autoMobile);
    }
}
