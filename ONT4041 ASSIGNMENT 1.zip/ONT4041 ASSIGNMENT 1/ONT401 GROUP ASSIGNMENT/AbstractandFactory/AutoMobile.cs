﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    abstract class AutoMobile //Client
    {
        public IShell TheShell { get; set; }
        public List <IChassis> TheChassis { get; set; }

        public CorporateHQ TheFactory { get; set; }//factory property "has a relationship"

        public AutoMobile(CorporateHQ TheFactory)
        {
            this.TheChassis = new List<IChassis>();
            this.TheFactory = TheFactory;
            Console.WriteLine("Creatting {0}", this.GetType().Name);
        }
        public virtual void MakeShell()
        {
            Console.WriteLine("Creating {0} car ", TheShell.GetType().Name);
        }
        public virtual void AddChassis()
        {
            Console.WriteLine("Adding chassis");

            foreach (IChassis Current in TheChassis)
                Console.WriteLine("- {0}", Current.GetType().Name);
        }
        public virtual void Assembly()
        {
            Console.WriteLine("Assembling the Automobile");
        }
    }
}
