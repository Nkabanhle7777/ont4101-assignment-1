﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
   public class MiniBusPartsFactory:MiniBusFactoryBase //ConcreteFactory
    {
      
        
        //public override IShell GetShell()
        //{
        //    return new MiniBusShell();
        //}
        //public override IChassis GetChassis()
        //{
        //    return new MiniBusChassis();
        //}
        //public override IWheel GetWheel()
        //{
        //    return new MiniBusWheel();
        //}
        //public override ITrim GetTrim()
        //{
        //    return new MiniBusTrim();
        //}

    }
}
