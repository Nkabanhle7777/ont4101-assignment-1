﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.SingletonandThreading
{
    public interface IAssemblyQueue<TAutoMobile> where TAutoMobile : class
    {
       
    }
}
