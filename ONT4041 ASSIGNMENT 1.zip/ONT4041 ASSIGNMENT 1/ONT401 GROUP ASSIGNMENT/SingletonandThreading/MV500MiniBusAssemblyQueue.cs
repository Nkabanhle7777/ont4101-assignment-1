﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.SingletonandThreading
{
    public class MV500MiniBusAssemblyQueue: IAssemblyQueue<MV500MiniBus>
    {
        private static MV500MiniBusAssemblyQueue _miniBusAssemblyQueue;
        static List<MV500MiniBus> _miniBusesQueued;

        public static MV500MiniBusAssemblyQueue InitializeMiniBusAssemblyQueue()
        {
            //Not thread safe
            if (_miniBusAssemblyQueue == null)
            {
                _miniBusAssemblyQueue = new MV500MiniBusAssemblyQueue();
                _miniBusesQueued = new List<MV500MiniBus>();
                Console.WriteLine("MV500 MiniBus Queue initialized");
            }
            return _miniBusAssemblyQueue;
        }
        public static void AddToQueue(MV500MiniBus _MiniBus)
        {
            _miniBusesQueued.Add(_MiniBus);
            Console.WriteLine("MV500 MiniBus added to Queue");
        }
        public static void RemoveFromQueue(MV500MiniBus _MiniBus)
        {
            _miniBusesQueued.Remove(_MiniBus);
            Console.WriteLine("MV500 MiniBus removed from Queue");
        }
        public static int GetNumberOfQueuedMiniBuses()
        {
            return _miniBusesQueued.Count;
        }
        public static List<MV500MiniBus> GetAllQueued()
        {
            return _miniBusesQueued;
        }

    }
}
