﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using ONT401_GROUP_ASSIGNMENT.Command;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class SprayBooth : ISprayCommand
    {
        public string Spray(IAutoMobile autoMobile, string Color)
        {
            string paint_process = null;
            if (autoMobile is LUX1000CAR)
            {
                paint_process = $"Spraying {Color} {autoMobile.Name}";
                autoMobile.Color = Color;
            }
            else if (autoMobile is MV500MiniBus)
            {
                paint_process = $"Spraying {Color} {autoMobile.Name}";
                autoMobile.Color = Color;
            }
            else if (paint_process == null)
                throw new Exception();

            return paint_process;
        }
        public async Task SimulateSpraysDelay()
        {
            await Task.Delay(2000);
        }
    }

  
    
}
    

