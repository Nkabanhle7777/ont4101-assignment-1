﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.SingletonandThreading
{
 public class LUX1000CarAssemblyQueue : IAssemblyQueue<LUX1000CAR>
    {
        private static LUX1000CarAssemblyQueue _carAssemblyQueue;
        static List<LUX1000CAR> _carsQueued;

        public static LUX1000CarAssemblyQueue InitializeCarAssemblyQueue()
        {
            //Not thread safe
            if (_carAssemblyQueue == null)
            {
                _carAssemblyQueue = new LUX1000CarAssemblyQueue();
                _carsQueued = new List<LUX1000CAR>();
                Console.WriteLine("MV500 MiniBus Queue initialized");
            }
            return _carAssemblyQueue;
        }
        public static void AddToQueue(LUX1000CAR car)
        {
            _carsQueued.Add(car);

        }
        public static void RemoveFromQueue(LUX1000CAR car)
        {
            _carsQueued.Remove(car);
        }
        public static int GetNumberOfQueuedCars()
        {
            return _carsQueued.Count;
        }
        public static List<LUX1000CAR> GetAllQueued()
        {
            return _carsQueued;
        }
    }
}
