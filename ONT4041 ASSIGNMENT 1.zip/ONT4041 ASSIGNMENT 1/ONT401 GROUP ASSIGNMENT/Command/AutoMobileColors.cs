﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.Command
{
    public static class AutoMobileColors
    {
        public const string Black = "Black";
        public const string White = "White";
    }
}
