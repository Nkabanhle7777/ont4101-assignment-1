﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT.Command
{
  public interface ISprayCommand
    {
        string Spray(IAutoMobile autoMobile, string Color);
    }
}
