﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using ONT401_GROUP_ASSIGNMENT.Command;

namespace ONT401_GROUP_ASSIGNMENT
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
       

      

        private void btnOrder_Click(object sender, EventArgs e)
        {
            if (rdbtnBlackLux.Checked)
            {
                //Black LUX1000
                LUX1000CAR car = new LUX1000CAR(AutoMobileColors.Black);
                OrderAutoMobile.Place(lblCarAssemblyLine, lblSpraybooth, lblCarQueue, car);
            }
            else if (rdbtnWhiteLux.Checked)
            {
                //White LUX1000
                LUX1000CAR car = new LUX1000CAR(AutoMobileColors.White);
                OrderAutoMobile.Place(lblCarAssemblyLine, lblSpraybooth, lblCarQueue, car);
            }
            else if (rdbtnBlackMV500.Checked)
            {
                //Black MV500
                MV500MiniBus miniBus = new MV500MiniBus(AutoMobileColors.Black);
                OrderAutoMobile.Place(lblMiniBusAssemblyKine, lblSpraybooth, lblCarQueue, miniBus);
            }
            else if (rdbtnMV500.Checked)
            {
                //White MV500
                MV500MiniBus miniBus = new MV500MiniBus(AutoMobileColors.White);
                OrderAutoMobile.Place(lblMiniBusAssemblyKine, lblSpraybooth, lblMiniBusQueue, miniBus);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lblMiniBusAssemblyKine_Click(object sender, EventArgs e)
        {

        }

        private void lblSpraybooth_Click(object sender, EventArgs e)
        {

        }
    }
    }

