﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    public abstract class CarAssemblyFactoryBase : IAssemblyFactory
    {
        public virtual IAutoMobile Assemble(IAutoMobile autoMobile)
        {
            LUX1000CAR _Lux1000CAR = new LUX1000CAR();
            _Lux1000CAR.Status = $"Performing Final Assembly of {autoMobile.Color} {autoMobile.Name}";
            _Lux1000CAR.IsCompletelyAssembled = true;
            return _Lux1000CAR;
        }

        public static async Task SimulateAssemblyDaley()
        {
            //2 seconds
            await Task.Delay(2000);
        }
    }
}

