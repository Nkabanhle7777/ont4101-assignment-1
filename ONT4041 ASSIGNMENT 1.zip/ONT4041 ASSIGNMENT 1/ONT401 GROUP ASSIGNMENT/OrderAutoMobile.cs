﻿using ONT401_GROUP_ASSIGNMENT.AbstractandFactory;
using ONT401_GROUP_ASSIGNMENT.SingletonandThreading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Label = System.Windows.Forms.Label;

namespace ONT401_GROUP_ASSIGNMENT
{
    public static class OrderAutoMobile
    {
        

        public static async void Place(Label assemblyLabel, Label sprayBoothLabel, Label queueLabel, IAutoMobile autoMobile)
        {

            string defaultLabelText = "Idle";

            if (autoMobile is LUX1000CAR)
            {
                CarPartsFactory _carPartsFactory = new CarPartsFactory();
                CarAssemblyFactory _carAssemblyFactory = new CarAssemblyFactory();
                LUX1000CAR _Car = autoMobile as LUX1000CAR;
                IAutoMobile finishedVehicle; //Fully assembled vehicle
                CarChassis carChassis;
                CarShell carShell;
                CarTrim carTrim;
                CarWheel carWheels;

                #region Car Assembly Line Process
                //If Assembly Line occupied, place car on  queue
                if (CarAssemblyLine.Status == AssemblyStatus.CARLINE_Occupied)
                {
                    LUX1000CarAssemblyQueue.AddToQueue(_Car);
                    queueLabel.Text = LUX1000CarAssemblyQueue.GetNumberOfQueuedCars().ToString();
                }
              

                if (CarAssemblyLine.Status == AssemblyStatus.CARLINE_Available)
                {
                    //Set Car Assembly Line to Occupied
                    CarAssemblyLine.Status = AssemblyStatus.CARLINE_Occupied;

                    //Simulate Assembly Line  
                    carChassis = (CarChassis)_carPartsFactory.CreateChassis(_Car);
                    carShell = (CarShell)_carPartsFactory.CreateShell(_Car);
                    carTrim = (CarTrim)_carPartsFactory.CreateTrim(_Car);
                    carWheels = (CarWheel)_carPartsFactory.CreateWheels(_Car);

                    //Chassis
                    assemblyLabel.Text = carChassis.Status;
                    await carChassis.SimulateConstractionDelay();

                    //Shell
                    assemblyLabel.Text = carShell.Status;
                    await carShell.SimulateConstractionDelay();

                    //Trim
                    assemblyLabel.Text = carTrim.Status;
                    await carTrim.SimulateConstractionDelay();

                    //Wheels
                    foreach (var wheelStatus in carWheels.WheelCreationListStatus)
                    {
                        assemblyLabel.Text = wheelStatus;
                        await carWheels.SimulateConstractionDelay();
                    }

                    finishedVehicle = _carAssemblyFactory.Assemble(_Car);
                    assemblyLabel.Text = finishedVehicle.Status;


                    if (finishedVehicle.IsCompletelyAssembled == true)
                    {
                        assemblyLabel.Text = $"Sent {_Car.Color} {finishedVehicle.Name} for painting";
                        SprayBooth sprayBooth = new SprayBooth();
                        var sprayingStatus = sprayBooth.Spray(finishedVehicle, _Car.Color);
                        sprayBoothLabel.Text = sprayingStatus;
                        await sprayBooth.SimulateSpraysDelay();
                        sprayBoothLabel.Text = defaultLabelText;
                        assemblyLabel.Text = defaultLabelText;
                    }

                    CarAssemblyLine.Status = AssemblyStatus.CARLINE_Available;

                    //Check for cars in queue
                    if (LUX1000CarAssemblyQueue.GetNumberOfQueuedCars() >= 1)
                    {
                        //Set Car AssemblyLine to Occupied 
                        CarAssemblyLine.Status = AssemblyStatus.CARLINE_Occupied;

                        foreach (var car in LUX1000CarAssemblyQueue.GetAllQueued().ToArray())
                        {
                            _Car = car;
                            //Simulate Assembly Line  
                            carChassis = (CarChassis)_carPartsFactory.CreateChassis(_Car);
                            carShell = (CarShell)_carPartsFactory.CreateShell(_Car);
                            carTrim = (CarTrim)_carPartsFactory.CreateTrim(_Car);
                            carWheels = (CarWheel)_carPartsFactory.CreateWheels(_Car);

                            //Chassis
                            assemblyLabel.Text = carChassis.Status;
                            await carChassis.SimulateConstractionDelay();

                            //Shell
                            assemblyLabel.Text = carShell.Status;
                            await carShell.SimulateConstractionDelay();

                            //Trim
                            assemblyLabel.Text = carTrim.Status;
                            await carTrim.SimulateConstractionDelay();

                            //Wheels
                            foreach (var wheelStatus in carWheels.WheelCreationListStatus)
                            {
                                assemblyLabel.Text = wheelStatus;
                                await carWheels.SimulateConstractionDelay();
                            }

                            finishedVehicle = _carAssemblyFactory.Assemble(_Car);
                            assemblyLabel.Text = finishedVehicle.Status;

                            if (finishedVehicle.IsCompletelyAssembled == true)
                            {
                                assemblyLabel.Text = $"Sent {_Car.Color} {finishedVehicle.Name} for painting";
                                SprayBooth sprayBooth = new SprayBooth();
                                var sprayingStatus = sprayBooth.Spray(finishedVehicle, _Car.Color);
                                sprayBoothLabel.Text = sprayingStatus;
                                await sprayBooth.SimulateSpraysDelay();
                                sprayBoothLabel.Text = defaultLabelText;
                                assemblyLabel.Text = defaultLabelText;
                            }

                            //Remove from queue and send to SprayBooth
                            LUX1000CarAssemblyQueue.RemoveFromQueue(_Car);
                            queueLabel.Text = LUX1000CarAssemblyQueue.GetNumberOfQueuedCars().ToString();
                        }
                        CarAssemblyLine.Status = AssemblyStatus.CARLINE_Available;
                        assemblyLabel.Text = defaultLabelText;
                    }
                }

                #endregion

            }
            else if (autoMobile is MV500MiniBus)
            {
                MiniBusPartsFactory _miniBusPartsFactory = new MiniBusPartsFactory();
                MiniBusAssemblyFactory _miniBusAssemblyFactory = new MiniBusAssemblyFactory();
                MV500MiniBus _MiniBus = autoMobile as MV500MiniBus; //Orderd Minibus
                IAutoMobile finishedVehicle; //Fully assembled vehicle
                MiniBusChassis miniBusChassis;
                MiniBusShell miniBusShell;
                MiniBusTrim miniBusTrim;
                MiniBusWheel miniBusWheel;

                #region MiniBus Assemnly Line
                //If MiniBus Assembly Line occupied, place car on  queue
                if (MiniBusAssemblyLine.Status == AssemblyStatus.MINILINE_Occupied)
                {
                    MV500MiniBusAssemblyQueue.AddToQueue(_MiniBus);
                    queueLabel.Text = MV500MiniBusAssemblyQueue.GetNumberOfQueuedMiniBuses().ToString();
                }


                if (MiniBusAssemblyLine.Status == AssemblyStatus.MINILINE_Available)
                {
                    //Set MiniBus Assembly Line to Occupied
                    MiniBusAssemblyLine.Status = AssemblyStatus.MINILINE_Occupied;

                    //Simulate Assembly Line    
                    miniBusChassis = (MiniBusChassis)_miniBusPartsFactory.CreateChassis(_MiniBus);
                    miniBusShell = (MiniBusShell)_miniBusPartsFactory.CreateShell(_MiniBus);
                    miniBusTrim = (MiniBusTrim)_miniBusPartsFactory.CreateTrim(_MiniBus);
                    miniBusWheel = (MiniBusWheel)_miniBusPartsFactory.CreateWheels(_MiniBus);

                    //Chassis
                    assemblyLabel.Text = miniBusChassis.Status;
                    await miniBusChassis.SimulateConstractionDelay();

                    //Shell
                    assemblyLabel.Text = miniBusShell.Status;
                    await miniBusShell.SimulateConstractionDelay();

                    //Trim
                    assemblyLabel.Text = miniBusTrim.Status;
                    await miniBusTrim.SimulateConstractionDelay();

                    //Wheels
                    foreach (var wheelStatus in miniBusWheel.WheelCreationListStatus)
                    {
                        assemblyLabel.Text = wheelStatus;
                        await miniBusWheel.SimulateConstractionDelay();
                    }

                    finishedVehicle = _miniBusAssemblyFactory.Assemble(_MiniBus);
                    assemblyLabel.Text = finishedVehicle.Status;

                    //Spraying process
                    if (finishedVehicle.IsCompletelyAssembled == true)
                    {
                        assemblyLabel.Text = $"Sent {_MiniBus.Color} {finishedVehicle.Name} for painting";
                        SprayBooth sprayBooth = new SprayBooth();
                        var sprayingStatus = sprayBooth.Spray(finishedVehicle, _MiniBus.Color);
                        sprayBoothLabel.Text = sprayingStatus;
                        await sprayBooth.SimulateSpraysDelay();
                        sprayBoothLabel.Text = defaultLabelText;
                        assemblyLabel.Text = defaultLabelText;
                    }

                    MiniBusAssemblyLine.Status = AssemblyStatus.MINILINE_Available;



                    if (MV500MiniBusAssemblyQueue.GetNumberOfQueuedMiniBuses() >= 1)
                    {
                        //Set Minibus assembly line to occupied
                        MiniBusAssemblyLine.Status = AssemblyStatus.MINILINE_Occupied;

                        foreach (var miniBus in MV500MiniBusAssemblyQueue.GetAllQueued().ToArray())
                        {
                            _MiniBus = miniBus;
                            miniBusChassis = (MiniBusChassis)_miniBusPartsFactory.CreateChassis(_MiniBus);
                            miniBusShell = (MiniBusShell)_miniBusPartsFactory.CreateShell(_MiniBus);
                            miniBusTrim = (MiniBusTrim)_miniBusPartsFactory.CreateTrim(_MiniBus);
                            miniBusWheel = (MiniBusWheel)_miniBusPartsFactory.CreateWheels(_MiniBus);

                            //Chassis
                            assemblyLabel.Text = miniBusChassis.Status;
                            await miniBusChassis.SimulateConstractionDelay();

                            //Shell
                            assemblyLabel.Text = miniBusShell.Status;
                            await miniBusShell.SimulateConstractionDelay();

                            //Trim
                            assemblyLabel.Text = miniBusTrim.Status;
                            await miniBusTrim.SimulateConstractionDelay();

                            //Wheels
                            foreach (var wheelStatus in miniBusWheel.WheelCreationListStatus)
                            {
                                assemblyLabel.Text = wheelStatus;
                                await miniBusWheel.SimulateConstractionDelay();
                            }

                            finishedVehicle = _miniBusAssemblyFactory.Assemble(_MiniBus);
                            assemblyLabel.Text = finishedVehicle.Status;

                            //Spraying process
                            if (finishedVehicle.IsCompletelyAssembled == true)
                            {
                                assemblyLabel.Text = $"Sent {_MiniBus.Color} {finishedVehicle.Name} for painting";
                                SprayBooth sprayBooth = new SprayBooth();
                                var sprayingStatus = sprayBooth.Spray(finishedVehicle, _MiniBus.Color);
                                sprayBoothLabel.Text = sprayingStatus;
                                await sprayBooth.SimulateSpraysDelay();
                                sprayBoothLabel.Text = defaultLabelText;
                                assemblyLabel.Text = defaultLabelText;
                            }

                            //Remove from queue and send to SprayBooth
                            MV500MiniBusAssemblyQueue.RemoveFromQueue(_MiniBus);
                            queueLabel.Text = MV500MiniBusAssemblyQueue.GetNumberOfQueuedMiniBuses().ToString();

                        }
                        MiniBusAssemblyLine.Status = AssemblyStatus.MINILINE_Available;

                    }
                }



                #endregion

            }
        }

       
    }
}
