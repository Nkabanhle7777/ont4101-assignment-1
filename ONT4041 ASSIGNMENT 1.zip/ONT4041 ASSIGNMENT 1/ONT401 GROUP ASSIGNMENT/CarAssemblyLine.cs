﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONT401_GROUP_ASSIGNMENT
{
    public class CarAssemblyLine
    {
        public static string Status { get; set; } = AbstractandFactory.AssemblyStatus.CARLINE_Available;
         //public CarAssemblyLine() : base(new CarPartsFactory())
        //{

        //}
        //public override AutoMobile makeAutoMobile(string AutoMobileType)
        //{
        //    AutoMobile TheAutoMobile = null;


        //    if (TheFactory != null)
        //    {
        //        switch (AutoMobileType)
        //        {
        //            case "White LUX1000": TheAutoMobile = new WhiteLux1000(TheFactory); break;
        //            case "Black LUX1000": TheAutoMobile = new BlackLux1000(TheFactory); break;
        //        }
        //    }
        //    return TheAutoMobile;
        //}


    }
}
