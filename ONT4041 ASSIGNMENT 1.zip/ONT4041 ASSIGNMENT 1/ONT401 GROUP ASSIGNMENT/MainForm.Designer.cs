﻿namespace ONT401_GROUP_ASSIGNMENT
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnOrder = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSpraybooth = new System.Windows.Forms.Label();
            this.lblMiniBusAssemblyKine = new System.Windows.Forms.Label();
            this.lblCarAssemblyLine = new System.Windows.Forms.Label();
            this.lblMiniBusQueue = new System.Windows.Forms.Label();
            this.lblCarQueue = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rdbtnBlackLux = new System.Windows.Forms.RadioButton();
            this.rdbtnWhiteLux = new System.Windows.Forms.RadioButton();
            this.rdbtnMV500 = new System.Windows.Forms.RadioButton();
            this.rdbtnBlackMV500 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Car Queue:";
            // 
            // btnOrder
            // 
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrder.Location = new System.Drawing.Point(12, 126);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(100, 83);
            this.btnOrder.TabIndex = 1;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblSpraybooth);
            this.panel1.Controls.Add(this.lblMiniBusAssemblyKine);
            this.panel1.Controls.Add(this.lblCarAssemblyLine);
            this.panel1.Controls.Add(this.lblMiniBusQueue);
            this.panel1.Controls.Add(this.lblCarQueue);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(118, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(519, 413);
            this.panel1.TabIndex = 3;
            // 
            // lblSpraybooth
            // 
            this.lblSpraybooth.AutoSize = true;
            this.lblSpraybooth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpraybooth.Location = new System.Drawing.Point(197, 265);
            this.lblSpraybooth.Name = "lblSpraybooth";
            this.lblSpraybooth.Size = new System.Drawing.Size(39, 20);
            this.lblSpraybooth.TabIndex = 9;
            this.lblSpraybooth.Text = "Idle";
            this.lblSpraybooth.Click += new System.EventHandler(this.lblSpraybooth_Click);
            // 
            // lblMiniBusAssemblyKine
            // 
            this.lblMiniBusAssemblyKine.AutoSize = true;
            this.lblMiniBusAssemblyKine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiniBusAssemblyKine.Location = new System.Drawing.Point(197, 199);
            this.lblMiniBusAssemblyKine.Name = "lblMiniBusAssemblyKine";
            this.lblMiniBusAssemblyKine.Size = new System.Drawing.Size(39, 20);
            this.lblMiniBusAssemblyKine.TabIndex = 8;
            this.lblMiniBusAssemblyKine.Text = "Idle";
            this.lblMiniBusAssemblyKine.Click += new System.EventHandler(this.lblMiniBusAssemblyKine_Click);
            // 
            // lblCarAssemblyLine
            // 
            this.lblCarAssemblyLine.AutoSize = true;
            this.lblCarAssemblyLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarAssemblyLine.Location = new System.Drawing.Point(197, 124);
            this.lblCarAssemblyLine.Name = "lblCarAssemblyLine";
            this.lblCarAssemblyLine.Size = new System.Drawing.Size(39, 20);
            this.lblCarAssemblyLine.TabIndex = 7;
            this.lblCarAssemblyLine.Text = "Idle";
            // 
            // lblMiniBusQueue
            // 
            this.lblMiniBusQueue.AutoSize = true;
            this.lblMiniBusQueue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiniBusQueue.Location = new System.Drawing.Point(313, 47);
            this.lblMiniBusQueue.Name = "lblMiniBusQueue";
            this.lblMiniBusQueue.Size = new System.Drawing.Size(19, 20);
            this.lblMiniBusQueue.TabIndex = 6;
            this.lblMiniBusQueue.Text = "0";
            // 
            // lblCarQueue
            // 
            this.lblCarQueue.AutoSize = true;
            this.lblCarQueue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarQueue.Location = new System.Drawing.Point(63, 47);
            this.lblCarQueue.Name = "lblCarQueue";
            this.lblCarQueue.Size = new System.Drawing.Size(19, 20);
            this.lblCarQueue.TabIndex = 5;
            this.lblCarQueue.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(153, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Spraybooth:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Minibus Assembly Line:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(117, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Car Assesmbly Line:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(242, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "MiniBus Queue:";
            // 
            // rdbtnBlackLux
            // 
            this.rdbtnBlackLux.AutoSize = true;
            this.rdbtnBlackLux.Location = new System.Drawing.Point(11, 26);
            this.rdbtnBlackLux.Name = "rdbtnBlackLux";
            this.rdbtnBlackLux.Size = new System.Drawing.Size(100, 17);
            this.rdbtnBlackLux.TabIndex = 4;
            this.rdbtnBlackLux.TabStop = true;
            this.rdbtnBlackLux.Text = "Black LUX1000";
            this.rdbtnBlackLux.UseVisualStyleBackColor = true;
            // 
            // rdbtnWhiteLux
            // 
            this.rdbtnWhiteLux.AutoSize = true;
            this.rdbtnWhiteLux.Location = new System.Drawing.Point(11, 49);
            this.rdbtnWhiteLux.Name = "rdbtnWhiteLux";
            this.rdbtnWhiteLux.Size = new System.Drawing.Size(101, 17);
            this.rdbtnWhiteLux.TabIndex = 5;
            this.rdbtnWhiteLux.TabStop = true;
            this.rdbtnWhiteLux.Text = "White LUX1000";
            this.rdbtnWhiteLux.UseVisualStyleBackColor = true;
            // 
            // rdbtnMV500
            // 
            this.rdbtnMV500.AutoSize = true;
            this.rdbtnMV500.Location = new System.Drawing.Point(12, 95);
            this.rdbtnMV500.Name = "rdbtnMV500";
            this.rdbtnMV500.Size = new System.Drawing.Size(90, 17);
            this.rdbtnMV500.TabIndex = 6;
            this.rdbtnMV500.TabStop = true;
            this.rdbtnMV500.Text = "White MV500";
            this.rdbtnMV500.UseVisualStyleBackColor = true;
            // 
            // rdbtnBlackMV500
            // 
            this.rdbtnBlackMV500.AutoSize = true;
            this.rdbtnBlackMV500.Location = new System.Drawing.Point(12, 72);
            this.rdbtnBlackMV500.Name = "rdbtnBlackMV500";
            this.rdbtnBlackMV500.Size = new System.Drawing.Size(89, 17);
            this.rdbtnBlackMV500.TabIndex = 7;
            this.rdbtnBlackMV500.TabStop = true;
            this.rdbtnBlackMV500.Text = "Black MV500";
            this.rdbtnBlackMV500.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 450);
            this.Controls.Add(this.rdbtnBlackMV500);
            this.Controls.Add(this.rdbtnMV500);
            this.Controls.Add(this.rdbtnWhiteLux);
            this.Controls.Add(this.rdbtnBlackLux);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnOrder);
            this.Name = "MainForm";
            this.Text = "Cool Rides";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSpraybooth;
        private System.Windows.Forms.Label lblMiniBusAssemblyKine;
        private System.Windows.Forms.Label lblCarAssemblyLine;
        private System.Windows.Forms.Label lblMiniBusQueue;
        private System.Windows.Forms.Label lblCarQueue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdbtnBlackLux;
        private System.Windows.Forms.RadioButton rdbtnWhiteLux;
        private System.Windows.Forms.RadioButton rdbtnMV500;
        private System.Windows.Forms.RadioButton rdbtnBlackMV500;
    }
}

